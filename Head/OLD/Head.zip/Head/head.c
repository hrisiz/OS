//--------------------------------------------
// NAME: Hristiqn Zarkov
// CLASS: XIб
// NUMBER: 27
// PROBLEM: #1
// FILE NAME: head.c
// FILE PURPOSE:
// 4ete ot daden fail purvite 10 reda i gi pokazva.
//---------------------------------------------

#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int print_top_ten_file_rows(char *file_name,int ARGC);
//--------------------------------------------
// FUNCTION: print_top_ten_file_rows
// принтира първите 10 реда от зададен файл.
// PARAMETERS:
// char *file_name - името на файла
// int ARGC - броят на аргументите
//----------------------------------------------
int read_and_print_from_stdin();
//--------------------------------------------
// FUNCTION: read_and_print_from_stdin
// чете от stdin и принтира само 10 реда.
// PARAMETERS:
// няма
//----------------------------------------------
int main(int ARGC,char *ARGV[]) {
        if (ARGC == 1) // проверява дали има вкарани аргументи
        {
                read_and_print_from_stdin();
        }
        else
        {
                int i;
                for (i = 1; i < ARGC; i++)
                {
                        char *file_name = ARGV[i];
                        if (ARGV[i][0] == '-')
                        {
                                read_and_print_from_stdin();
                        }
                        else
                        {
                                print_top_ten_file_rows(file_name,ARGC);
                        }
                }
        }
        return 0;
}
int read_and_print_from_stdin(){
        size_t bytes_read;
        char buffer; // променлива която ще съхранява взетата стойност от stdin
        int lines = 0; // прочетените редове са 0 в началото
        do
        {
        	bytes_read = read(STDIN_FILENO,&buffer, 1);
                if(bytes_read < 0){// чете от stdin и връща прочетеното на применливата buffer като използва препратка, а стоиността от фукцията се връща на променливата bytes_read
                	 perror("head : cannot read on stdout:");
                	 return -2;
               	}
                if (buffer == '\n') // проверява дали е намерило нов ред ако е да увеличи редовете
                {
                        lines++;
                }
                if (write(STDOUT_FILENO,&buffer,bytes_read) < 0) // принтира символа и проверява дали се е получило принтирането
                {
                        perror("head : cannot write on stdout:");
                        return -3;
                }
        }
        while (bytes_read != 0 && lines < 10);
}
int print_top_ten_file_rows(char *file_name,int ARGC){
        int file;
        file = open(file_name,O_RDONLY);// отваря файла с име file_name с метода O_RDONLY- само за четене и връща стойността на променливата file
        if (file < 0) // проверява дали се е отворил файла както трябва ако не вади грешка
        {
                char error[100];
                strcpy(error,"head : cannot open ’");// дава стойности на променливата error
                strcat(error,file_name); // добавя file_name на променливата error
                strcat(error,"’ for reading");// добавя ’ for reading на променливата error
                perror(error);
                return -1;
        }
        if (ARGC > 2) // проверява колко са аргументите(файловете) и ако са повече от 1 принта техните имена
        {
                char file_name_p[100];
                strcpy(file_name_p,"==> ");// задава ==> на променливата file_name_p
                strcat(file_name_p,file_name);// добавя file_name на променливата file_name_p
                strcat(file_name_p," <==");// добаея <== на променливата file_name_p
                if (write(STDOUT_FILENO,file_name_p,strlen(file_name_p)) == -1) // принтира символите и проверява дали се е получило принтирането
                {
                        perror("head : cannot write on stdout :");
                        return -2;
                }
                if (write(STDOUT_FILENO,"\n",1) == -1)// принтира нов ред и проверява дали се е получило принтирането
                {
                        char error[100];
                        strcpy(error,"head : cannot write a newline");// дава стойности на променливата error
                        strcat(error,file_name);// добавя file_name на променливата error
                        perror(error);
                        return -2;
                }
        }
        size_t bytes_read;
        char buffer;
        int lines = 0;
        do
        {
                bytes_read = read(file,&buffer, 1); // чете от файла и връща прочетеното на применливата buffer като използва препратка, а стоиността от фукцията се връща на променливата bytes_read
                if(bytes_read < 0){// чете от stdin и връща прочетеното на применливата buffer като използва препратка, а стоиността от фукцията се връща на променливата bytes_read
                	 perror("head : cannot read on stdout:");
                	 return -2;
               	}
                if (buffer == '\n') // проверява дали е намерило нов ред ако е да увеличи редовете
                {
                        lines++;
                }
                if (write(STDOUT_FILENO,&buffer,bytes_read) == -1) // принтира символа и проверява дали се е получило принтирането
                {
                        perror("head : cannot write on stdout:");
                        return -2;
                }
        }
        while (bytes_read != 0 && lines < 10);
        if (close(file) != 0)  // затваря файла и проверява дали се е затворил ако не е вади грешка
        {
                char error[100];
                strcpy(error,"head : cannot close ");// дава стойности на променливата error
                strcat(error,file_name);// добавя file_name на променливата error
                strcat(error,"’"); // добавя ’ на променливата error
                perror(error);
                return -3;
        }
}
